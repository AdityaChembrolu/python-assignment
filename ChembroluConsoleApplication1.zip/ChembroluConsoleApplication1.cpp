
#include <iostream>
#include <fstream>
#include <string>
#include <cctype>
#include <cstring>

using namespace std;

int countWord(string line)
{

    int word_count = 0;
    bool in_word = false;

    for (char c : line) {
        if (isspace(c) || c == '.') {
            in_word = false;
        }
        else if (!in_word) {
            word_count++;
            in_word = true;
        }
    }

    //std::cout << "Number of words: " << word_count << std::endl;
    return word_count;
}



int main()
{

    int count = 0;

    ifstream myFile;

    myFile.open("trees.txt", ios::in);

    if (myFile.is_open())
    {
        string line;
       

        while (getline(myFile, line))
        {

            int word_count = countWord(line);
            std::cout << "Number of words: " << word_count << std::endl;

            std::size_t length = line.length();
            std::cout << "size_t: " << length << std::endl;

            string abbr = "";
            int i = 1;
            if (word_count <= 1)
            {

                if (length <= 3)
                {
                    abbr = line;
                }
                else
                {
                    for (char& c : line) {
                        //std::cout << c << std::endl;
                        if (i == 1)
                        {
                            //append; 
                            abbr += c;
                            //abbr.append(1, c);  // append 1 character

                        }
                        if (i == 3)
                        {
                            //append
                            abbr += c;
                            //abbr.append(1, c);  // append 1 character
                        }
                        if (i == 4)
                        {
                            //append
                            abbr += c;
                        }
                        i++;
                        //c = toupper(c);
                    }
                }

                
            }
            else {

            }
           
            for (char& c : abbr) {
                c = toupper(c);
            }
            std::cout << abbr << std::endl;
            std::cout << line << std::endl;

           /* string abbreviation = line.substr(0, 3);
            
            while (abbreviation.length() < 3) {
                abbreviation += " ";
            }*/
           /* for (char& c : abbr) {
                c = toupper(c);
            }
            std::cout << abbr << std::endl;
            std::cout << line << std::endl;*/
        }
        myFile.close();
    }
    else {
        std::cout << "Could not open the file" << std::endl;
    }


}
